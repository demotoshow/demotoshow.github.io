#!/bin/bash

. ./path.sh
scp_file=$1

# check if file not exist
while read line; do
    path=`echo $line | awk '{print $2}'`
    if [ ! -e $path ]; then
        echo $path
    fi
done < $scp_file
